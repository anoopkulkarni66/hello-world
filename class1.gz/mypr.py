print "My Python Program"

print "Second Line"
