import re
from ciscoconfparse import CiscoConfParse

cfg = CiscoConfParse("cisco.txt")

crypto = cfg.find_objects_w_child(parentspec = r"^crypto map CRYPTO", childspec = r"set pfs group2")

print crypto

for i in crypto:
    print i.text
    for child in i.children:
        print child.text


crypto2 = cfg.find_objects_wo_child(parentspec = r"^crypto map CRYPTO", childspec = r"AES")

for j in crypto2:
    print j.text
    for childs in j.children:
        print childs.text

print
print "\nCrypto maps not using AES:"
for entry in crypto2:
    for child in entry.children:
        if 'transform' in child.text:
            match = re.search(r"set transform-set (.*)$", child.text)
            encryption = match.group(1)
    print "  {0} >>> {1}".format(entry.text.strip(), encryption)
print


