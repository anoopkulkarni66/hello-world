from ciscoconfparse import CiscoConfParse

cfg = CiscoConfParse("cisco.txt")

crypto = cfg.find_objects(r"^crypto map CRYPTO")

for i in crypto:
    print i.text
    for child in i.children:
        print child.text
        
       

